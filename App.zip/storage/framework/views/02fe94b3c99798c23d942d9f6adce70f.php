<div>
    <h1>Please Verify ur email by clicking on the button blew</h1>

    <a style="background :blue;color:white;" href="<?php echo e($url); ?>">Verify Email
    </a>
</div><?php /**PATH D:\pkl2\App\resources\views/emails/email-verification-message.blade.php ENDPATH**/ ?>