<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e(env('APP_NAME')); ?></title>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
</head>
<body class="bg-slate-100 text-slate-900">
    <header class="bg-slate-800 shadow-lg">
        <nav class="p-5 max-w-screen-lg mx-auto flex items-center justify-between">
            <a href="/posts" class="nav-link text-white">Home</a>

            <?php if(auth()->guard()->check()): ?>
                <div class="relative grid place-items-center" x-data="{ open: false}">
                    
                    <button @click="open = !open" type="button" class="round-btn">
                        <img src="https://picsum.photos/200" alt="">
                    </button>

                    
                    <div x-show="open" @click.outside="open=false" class="bg-white shadow-lg absolute top-10 right-0 rounded-lg overflow-hidden font-light">

                        <p class="username"><?php echo e(auth()->user()->username); ?></p>
                        <a href="/dashboard" class="block hover:bg-slate-100 pl-4 pr-8 py-2 mb-1">Dashboard</a>
                        <form action="/logout" method="post"> 
                            <?php echo csrf_field(); ?>   
                            <button class="block w-full text-left hover:bg-slate-100 pl-4 pr-8 py-2">LogOut</button>
                        </form>

                    </div>
                </div>
            <?php endif; ?>

            <?php if(auth()->guard()->guest()): ?>                
            <div class="flex items-center gap-4">
                <a href="/login" class="nav-link text-white">Login</a>
                <a href="/register" class="nav-link text-white">Register</a>
            </div>
            <?php endif; ?>
        </nav>
    </header>

    <main class="py-8 px-4 mx-auto max-w-screen-lg">
        <?php echo e($slot); ?>

    </main>
</body>
</html>
<?php /**PATH C:\laragon\www\App\resources\views/components/layout.blade.php ENDPATH**/ ?>